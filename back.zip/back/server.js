const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Use this for fetch support in Node.js
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on('connected', () => {
  console.log('✅ Connected to MongoDB');
});

mongoose.connection.on('error', (err) => {
  console.error('❌ MongoDB connection error:', err);
});

// Schemas
const messageSchema = new mongoose.Schema({
  userId: String,
  message: String,
  response: String,
  timestamp: { type: Date, default: Date.now },
  category: { type: String, default: 'general' },
});

const sessionSchema = new mongoose.Schema({
  userId: { type: String, unique: true },
  lastActive: { type: Date, default: Date.now },
  messageCount: { type: Number, default: 0 },
  interests: [String],
});

const Message = mongoose.model('Message', messageSchema);
const Session = mongoose.model('Session', sessionSchema);

// Gemini AI Integration using REST API
class CampusPeAI {
  constructor() {
    this.apiKey = process.env.GEMINI_API_KEY;
    this.apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.apiKey}`;
  }

  async processMessage(message, userId) {
    let responseText = '';
    const category = 'general';

    try {
      const payload = {
        contents: [
          {
            parts: [{ text: message }],
            role: 'user',
          },
        ],
      };

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.candidates && data.candidates.length > 0) {
        responseText = data.candidates[0].content.parts[0].text;
      } else {
        responseText = "I'm not sure how to respond to that.";
      }
    } catch (err) {
      console.error('❌ Gemini API error:', err);
      responseText = "Sorry, I'm having trouble processing your request.";
    }

    try {
      await Message.create({ userId, message, response: responseText, category });
      await Session.findOneAndUpdate(
        { userId },
        {
          lastActive: new Date(),
          $inc: { messageCount: 1 },
          $addToSet: { interests: category },
        },
        { upsert: true }
      );
    } catch (err) {
      console.error('❌ DB Save Error:', err);
    }

    return { response: responseText, category };
  }
}

const campusPeAI = new CampusPeAI();

// Routes
app.post('/api/chat', async (req, res) => {
  const { message, userId } = req.body;
  if (!message || !userId) {
    return res.status(400).json({ error: 'Message and userId required' });
  }

  try {
    const result = await campusPeAI.processMessage(message, userId);
    res.json({ ...result, timestamp: new Date() });
  } catch (error) {
    console.error('❌ Chat API Error:', error);
    res.status(500).json({ error: 'Processing failed', response: 'Please try again later.' });
  }
});

app.get('/api/chat/history/:userId', async (req, res) => {
  try {
    const messages = await Message.find({ userId: req.params.userId }).sort({ timestamp: -1 }).limit(50);
    res.json(messages.reverse());
  } catch (err) {
    console.error('❌ History Error:', err);
    res.status(500).json({ error: 'Failed to fetch chat history' });
  }
});

app.get('/api/session/:userId', async (req, res) => {
  try {
    const session = await Session.findOne({ userId: req.params.userId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json(session);
  } catch (err) {
    console.error('❌ Session Error:', err);
    res.status(500).json({ error: 'Failed to fetch session info' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'CampusPe AI Backend is running', timestamp: new Date() });
});

app.use((error, req, res, next) => {
  console.error('❌ Unhandled error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 CampusPe AI Backend running on port ${PORT}`);
});
