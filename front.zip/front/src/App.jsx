import CampusPeChat from './Chat'

function App() {

  return (
   <CampusPeChat/>
  )
}

export default App
