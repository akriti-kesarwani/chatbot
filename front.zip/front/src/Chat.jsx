import { useState, useEffect, useRef } from 'react';
import { Send, Phone, Video, MoreVertical, Smile, Paperclip, Mic } from 'lucide-react';
import './App.css';

const CampusPeChat = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! I'm CampusPe AI Assistant. I'm here to help you with admissions, fees, jobs, courses, and general education queries. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
      status: 'read',
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

const cleanText = (text) => {
  // Convert markdown-style lists into HTML lists
  const lines = text.split('\n').filter(Boolean);
  let formatted = '';
  let insideList = false;

  lines.forEach(line => {
    if (line.trim().startsWith('*')) {
      if (!insideList) {
        formatted += '<ul>';
        insideList = true;
      }
      const cleanedLine = line.replace(/^\*\s*/, '').replace(/\*\*/g, '');
      formatted += `<li>${cleanedLine.trim()}</li>`;
    } else {
      if (insideList) {
        formatted += '</ul>';
        insideList = false;
      }
      formatted += `<p>${line.replace(/\*\*/g, '').trim()}</p>`;
    }
  });

  if (insideList) formatted += '</ul>';
  return formatted;
};


  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
      status: 'sent',
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    try {
      const response = await fetch('http://localhost:5001/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: inputMessage, userId: 'user123' }),
      });

      const data = await response.json();
      const cleanedText = cleanText(data.response);

      setTimeout(() => {
        const botMessage = {
          id: Date.now() + 1,
          text: cleanedText,
          sender: 'bot',
          timestamp: new Date(),
          status: 'read',
        };
        setMessages((prev) => [...prev, botMessage]);
        setIsTyping(false);
      }, 1200);
    } catch (error) {
      console.error('Error sending message:', error);
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          text: "Sorry, I'm having trouble connecting right now. Please try again later.",
          sender: 'bot',
          timestamp: new Date(),
          status: 'read',
        },
      ]);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') sendMessage();
  };

  const formatTime = (timestamp) =>
    new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });

  const MessageBubble = ({ message }) => {
  const isUser = message.sender === 'user';
  return (
    <div className={`message-wrapper ${isUser ? 'message-right' : 'message-left'}`}>
      <div className={`message-bubble ${isUser ? 'user-bubble' : 'bot-bubble'}`}>
        {isUser ? (
          <p className="message-text">{message.text}</p>
        ) : (
          <div
            className="message-text"
            dangerouslySetInnerHTML={{ __html: message.text }}
          />
        )}
        <div className="message-meta">
          <span>{formatTime(message.timestamp)}</span>
          {isUser && <span className="message-status">✓✓</span>}
        </div>
      </div>
    </div>
  );
};


  return (
    <div className="chat-container">
      {/* Header */}
      <div className="chat-header">
        <div className="header-left">
          <div className="avatar">CP</div>
          <div>
            <h1 className="assistant-name">CampusPe AI Assistant</h1>
            <p className="status-text">{isOnline ? 'Online' : 'Last seen recently'}</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="chat-messages">
        <div className="welcome-box">
          <strong>Welcome to CampusPe!</strong> I can help you with admissions, fees, jobs, courses, and educational guidance.
        </div>

        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {isTyping && (
          <div className="typing-indicator">
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
          </div>
        )}
        <div ref={messagesEndRef}></div>
      </div>

      {/* Input */}
      <div className="chat-input">
        <button><Smile /></button>
        <button><Paperclip /></button>
        <div className="input-box">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me about admissions, fees, jobs, courses..."
          />
        </div>

          <button onClick={sendMessage} className="send-button">
            <Send />
          </button>

      </div>

      {/* Quick Actions */}
      <div className="quick-actions">
        <button onClick={() => setInputMessage('Tell me about admissions')}>Admissions</button>
        <button onClick={() => setInputMessage('What are the fee structures?')}>Fees & Finance</button>
        <button onClick={() => setInputMessage('Help me find jobs')}>Jobs & Careers</button>
        <button onClick={() => setInputMessage('Show me available courses')}>Courses</button>
      </div>
    </div>
  );
};

export default CampusPeChat;
